import java.util.Scanner;

// 해당 코드들은 인텔리주로 작성하였으며 실행하는 프로그램마다 class 개별 실행을 지원하지 않을 수 있음. 번거로우시겠지만 개별실행을 원하신다면 주석처리해서 코드 확인 부탁드립니다..

public class Question1 {
    public static void main(String[] args) {



    }

}

class Question2{
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int sec = sc.nextInt(); // sec의 값을 입력받고 저장
        int mm = sec/60;    // int형 mm을 선언하고 sec 값을 60으로 나눈 값의 몫을 저장
        int ss = sec%60; // int형 ss를 선언하고 sec 값을 60으로 나눈 값의 나머지를 저장

        if(sec>=3600){ // sec의 값이 3600 이상이면
            System.out.println("오류!"); // 오류! 라는 메시지를 띄운다
        } else {
            System.out.println(mm+"분"+ss+"초"); // 3600 미만에서는 정상적으로 출력되도록.
        }

    }
}

class Question3 {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in); // 인수와 사칙연산을 입력받기 위한 스캐닝 변수 생성

        int a = sc.nextInt(); // int형 변수 a를 입력받음
        int b = sc.nextInt(); // int형 변수 b를 입력받음

        String c = sc.next(); // String형 변수 c를 입력받음

        if (c.equals("+")) { // 만약 c가 "+"라면
            System.out.println("덧셈의 결과는" + (a + b)); // 해당 문구를 연산 결과와 함께 출력
        }
        else if(c.equals("-")) { // 만약 c가 "-"라면
            System.out.println("뺄셈의 결과는" + (a - b));
        } else if (c.equals("*") || c.equals("x") || c.equals("X")) { // 만약 c가 "*"거나 "x"거나 "X" 라면
            System.out.println("곱셈의 결과는" + (a * b));
        } else { // 만약 c가 다른 변수를 입력받았으면
            System.out.println("입력받은 연산자가 올바르지 않습니다,");
        }
    }
}

class Question4{
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        int a = sc.nextInt(); // 인트형 a를 입력받고 값 저장
        int b = sc.nextInt(); // 인트형 b를 입력받고 값 저장
        int c = sc.nextInt(); // 인트형 c를 입력받고 값 저장

        System.out.println(a + " " + b + " " + c + " "); // 식으로 취급되지 않기 위해 사이사이에 공백을 넣어줌
        // 가독성 나빠서 공백 사이에도 띄워쓰기를 적용함
        // print 함수도 써봤으나 a+b 연산 결과값과 붙어 나와서 println으로 결정함

        System.out.println(a+b);

    }

}

class Question5{
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in); // 데이터 개수를 입력받기 위한 Scanner 정의

        // 데이터의 개수(n개)를 입력받고 - count? 단순히 개수만 입력받는 것이라서 int형 정수? - 실수로 개수를 입력받지 않으니 정수형이 유력?
        int datacount = sc.nextInt();

        // 그 데이터의 개수만큼 정수형(int) 데이터를 입력받는다. (단, 배열이용 x)
        int recycled = datacount;

        // 이 때 데이터들의 최대값, 최소값, 평균, 합계를 구해 출력한다. ( 평균은 실수로 출력하도록 한다.) (입력받는 데이터 범위는 1~10만으로 제한한다.)

    }

}


// 나머지 6-10번 문제는 Q68 패키지 안에 있음







