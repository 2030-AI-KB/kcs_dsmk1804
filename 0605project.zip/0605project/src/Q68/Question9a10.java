package Q68;

/*
아래의 조건대로 클래스를 구현하시오

        클래스의 이름과 멤버들을 살펴보고, 클래스 간 상속 관계도 함께 구현 (인터페이스 개념을 묻고 있지 않음)

        animal class: cry() 추상메소드

        dog class: cry() - 강아지 울음소리 출력

        cat class: cry() - 고양이 울음소리 출력

        bird class: cry() - 새 울음소리 출력
*/

// cry가 상속의 주체 , 도그. 캣 버드는 animal의 cry() 객체를 상속받는 존재.

public class Question9a10{ //cry 메소드 호출
    public static void main(String[] args) {
        Animal dog = new Dog(); // Animal dog 변수 정의, dog 클래스의 인스턴스 생성, 참조 가능
        dog.cry(); // 멍멍 출력

        Animal cat = new Cat(); // 도그와 이하동문
        cat.cry(); // 야옹 출력

        Animal bird = new Bird(); // 도그와 이하동문2
        bird.cry(); // 짹쨱 출력
    }
}

abstract class Animal{ // 인터페이스의 개념을 묻는 것이 아니고, 상속(extends)의 개념을 말했으니 abstract가 적당할 것으로 생각하였다. - 추상 클래스 Animal
    public abstract void cry(); // 추상메소드 cry() 생성
}

class Dog extends Animal{ // dog 클래스에 animal 상속 - 추상메소드 cry() 구현
    @Override
    public void cry(){ // 추상메소드 cry() 구현
        System.out.println("멍멍");
    }
}

class Cat extends Animal{ //Cat 클래스에 animal 상속
    @Override
    public void cry(){ // 추상메소드 cry() 구현
        System.out.println("야옹");
    }
}

class Bird extends Animal { //Bird 클래스에 animal 상속
    @Override
    public void cry() { // 추상메소드 cry() 구현
        System.out.println("짹짹");
    }


}
