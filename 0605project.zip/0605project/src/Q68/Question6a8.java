package Q68;

public class Question6a8 {
    public static void main(String[] args) {
        // 아래 멤버들로 구성되어 있는 3개 클래스를 구현
        // (각 클래스의 멤버들을 살펴보고 클래스 간 상속 관계도 구현.)
        // 필드는 모두 private, 메소드 및 생성자는 모두 public

        // person class: (필드) (name, age) (메소드) 각 필드에 대한 getter and setter 메소드 (생성자) 매개변수로 전달받은 값에 대해 각 필드 초기화하는 메소드
        // student class: (필드) (name, age), major (메소드) printStudent() -> 각 필드값 출력하는 메소드 (생성자) 매개변수로 전달받은 값에 대해 각 필드 초기화하는 메소드
        // professor class: (필드) (name, age), company (메소드) printProfessor() -> 각 필드값 출력하는 메소드 (생성자) 매개변수로 전달받은 값에 대해 각 필드 초기화하는 메소드

        class Person {
            private String name; // priavte 접근 제어자 설정, String형 변수 name 선언 (필드)
            private int age;    // priavte 접근 제어자 설정, 인트형 변수 age 선언 (필드)

            public Person(String name, int age) { // person 안의 메소드와 생성자는 모두 public어야 한다. (변수= 메소드)
                this.name = name;
                this.age = age;
            }

            public String getName() {
                return name;
            }

            public void setName(String name) {
                this.name = name;
            }

            public int getAge() {
                return age;
            }

            public void setAge(int age) {
                this.age = age;
            }
        }

        class Student extends Person {
            private String major;

            public Student(String name, int age, String major) {
                super(name, age);
                this.major = major;
            }

            public void printStudent() {
                System.out.println("이름: " + getName());
                System.out.println("나이: " + getAge());
                System.out.println("전공: " + major);
            }
        }

        class Professor extends Person {
            private String company;

            public Professor(String name, int age, String company) {
                super(name, age);
                this.company = company;
            }

            public void printProfessor() {
                System.out.println("이름 " + getName());
                System.out.println("나이 " + getAge());
                System.out.println("직장 " + company);
            }
        }

        // 테스트
        Student student = new Student("김길동",30,"컴퓨터공학과");
        Professor professor = new Professor("홍길동",35,"KB");

        student.printStudent();
        professor.printProfessor();
    }
}
