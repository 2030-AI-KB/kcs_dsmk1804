package com;

import com.Common.AppService;
import com.Common.ServiceForward;
import com.example.service.LoginFormService;
import com.example.service.LoginProcessService;
import com.example.service.MainService;
import com.member.Service.AjaxCheckIdService;
import com.member.Service.JoinFormService;
import com.member.Service.JoinService;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("*.do")
public class FrontController extends HttpServlet { // Controller 클래스가 HttpServlet 을 확장(extends)한다.
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response);
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doProcess(request, response);
    }

    private void doProcess(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String command = request.getRequestURI();

        String name = null;

        ServiceForward forward = null;


        try {
            if (command.equals("/main.do")) {
                AppService service = new MainService();
                forward = service.execute(request, response);
            } else if (command.equals("/member/join/form.do")) {
                AppService service = new JoinFormService();
                forward = service.execute(request, response);
            } else if (command.equals("/member/check/id.do")) {
                AppService service = new AjaxCheckIdService();
                forward = service.execute(request, response);
            }
            else if (command.equals("/member/check/id.do")) {
                AppService service = new LoginProcessService();
                forward = service.execute(request, response);
            }
        } catch (
                Exception e) {
            e.printStackTrace();
        }

        if (forward != null) {
            if (forward.isRedirect()) {
            // 리다이렉트
            } else {
                // 포워드
                RequestDispatcher dispatcher = request.getRequestDispatcher(forward.getPath());
                dispatcher.forward(request, response);
            }
        } else {
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter out = response.getWriter();
            out.println("<script>alert('잘못된 접근입니다.');history.back();</script>");
            out.close();
        }
    }

}

// Servlet: 경로를 제어
// doPost: , doGet:
// 백엔드에서 경로를 이동하는 방법: view, 다른 주소
// view로 이동하면 경로가 노출되지 않음
// 다른 경로로 요청하면 주소가 바뀐다. -> 리다이렉트
// fowarding: 내 처음주소가 바뀌지 않음.
// WEB INF

// uri : 식별자 / url : 식별자 + 경로(위치) / uri가 url일 수는 있지만, url이 uri일 수는 없음. (uri가 url보다 더 포괄적인 개념을 갖고 있다고 보면 될듯)
// 쿼리스트링 - 키와 밸류로 이루어져 있음

//root로 요청하면 if로 처리