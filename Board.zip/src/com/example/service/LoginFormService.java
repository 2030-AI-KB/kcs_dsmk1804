package com.example.service;

import com.Common.AppService;
import com.Common.BCrypt;
import com.Common.ServiceForward;
import com.Common.Validator;
import com.Common.dto.MemberDTO;
import com.member.Ds.MemberDs;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.lang.reflect.Member;

import static com.Common.Constants.BASIC_VIEWS_PATH;

public class LoginFormService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 폼의 데이터 로드
        String loginId = request.getParameter("loginId");
        String password = request.getParameter("password");

        // 데이터 빈값 검사
        if(Validator.isStringEmpty(loginId)|| Validator.isStringEmpty(password)){
            return null;
        }

        // 입력한 아이디로 데이터베이스에서 회원 정보 검색
        MemberDs ds = new MemberDs();
        MemberDTO memberDTO = ds.selectMemberInfoByLoginId(loginId);

        if(memberDTO == null){
            return null;
        }

        // 비밀번호 비교 - BCrypt의 checkpw 메소드를 이용하여, 현재 비밀번호(=password)와 입력한 비밀번호(memberDTO.getPassword())를 비교한다.
        boolean isSame = BCrypt.checkpw(password, memberDTO.getPassword());

        if(isSame){
            return null; // 비밀번호를 틀렸을 때
        }

        // 세션에 회원정보 저장
        HttpSession session =request.getSession();
        session.setAttribute("mi", memberDTO);

        return  ServiceForward.builder()
                .path(BASIC_VIEWS_PATH + "main.jsp")
                .build();
    }
}
