package com.example.service;

import com.Common.AppService;
import com.Common.ServiceForward;
import com.example.ds.ExampleDs;
import com.member.Ds.MemberDs;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.Common.Constants.BASIC_VIEWS_PATH;

public class ResultService implements AppService {

    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception{
        // String형 name을 선언하고 myName 키 값으로 입력한데이터를 저장한다.
        String name = request.getParameter("myName");

        //request 객체에 뷰로 전송할 name 데이터를 저장한다.
        request.setAttribute("name", name);
        ExampleDs ds = new ExampleDs();
        ds.insertName(name);

        // ServiceForward에 객체 forward를 선언하고 builder를 통해 경로 데이터를 저장한다.
        ServiceForward forward = ServiceForward.builder()
                .path(BASIC_VIEWS_PATH+ "result.jsp")
                .build();

        /* forward 객체를 리턴한다. */
        return forward;
    }
}
