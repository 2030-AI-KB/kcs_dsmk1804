package com.example.service;

import com.Common.AppService;
import com.Common.ServiceForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.Common.Constants.BASIC_VIEWS_PATH;

public class LoginProcessService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        return  ServiceForward.builder()
                .path(BASIC_VIEWS_PATH + "main.jsp")
                .build();
    }
}
