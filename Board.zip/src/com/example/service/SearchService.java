package com.example.service;

import com.Common.AppService;
import com.Common.ServiceForward;
import com.example.ds.ExampleDs;
import com.member.Ds.MemberDs;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.regex.Pattern;

import static com.Common.Constants.BASIC_VIEWS_PATH;

public class SearchService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {

        String input = request.getParameter("myNameId");

        // input 변수의 데이터가 숫자인지 확인
        if(input == null || input.equals("") || !Pattern.matches("^[0-9]{1,9}$", input)){
            // 중괄호: 해당 인수만을 허용함 // 대괄호: 문자열 길이
            // 오류 메시지
            return null;
        }

        // 정수형 id를 선언하고 input 변수를 숫자로 변환한다.
        int id = Integer.parseInt(input);

        // String 형 name을 선언하고, 데이터 베이스에서 id로 이름을 검색해서 저장한다.
        ExampleDs ds = new ExampleDs();
        String name = ds.selectNameById(id);
        if (name == null){
            name = "검색 결과가 존재하지 않습니다.";
        }

        // request 객체에 attribute에 검색한 이름을 저장한다.
        request.setAttribute("result", name);

        // view를 위한 forward 객체 리턴
        return  ServiceForward.builder()
                .path(BASIC_VIEWS_PATH + "search.jsp") // search.jsp 페이지 경로로 이동
                .build();
    }
}
