package com.example.ds;

import com.AppDao;

import java.sql.Connection;

import static com.Common.JdbcUtil.*;

public class ExampleDs {

    private Connection conn;

    private AppDao setDao(){
        AppDao dao = AppDao.getInstance();
        this.conn = getConnection();
        dao.setConnection(this.conn);
        return dao;

    }

    public int selectAccountCountByLoginId(String loginId){
        AppDao dao = setDao();
        int count = dao.selectAccountCountByLoginId(loginId);
        close(conn);
        return count;
    }


    public void insertName(String name){
        AppDao dao = setDao();
        boolean isSuccess = dao.insertName(name);

        if(isSuccess){
            commit(this.conn);

        } else {
            rollback(this.conn);
        }
        close(conn);
    }

    }
}
