package com;

import com.Common.dto.MemberDTO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

import static com.Common.JdbcUtil.close;

public class AppDao {
    private Connection conn;

    private AppDao() { // 생성자를 private으로 만들어 외부에서 객체를 못 만들도록 만듦


    }

    private static class LazyHolder { // 여기 내에서만 쓸 수 있는 class
        private static final AppDao INSTANCE = new AppDao();
    }

    public static AppDao getInstance() {
        return LazyHolder.INSTANCE;

    }

    public void setConnection(Connection conn) {
        this.conn = conn;
    }

    public boolean insertName(String name) {
        PreparedStatement pstmt = null;
        int count = 0;

        try {
            pstmt = conn.prepareStatement("insert into my_name(name) values (?)");
            pstmt.setString(1, name); // 괄호 안: ?안에 String이 들어갈 자리 // 괄호 안 숫자: 물음표 개수에 따라서 달라진다 ex: 물음표 갯수가 5이면 안에 숫자는 5로 할당하면 된다.
            count = pstmt.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        } finally { // 예외 발생여부에 관계없이 늘 실행되는 코드
            close(pstmt); // 오버로딩됨
        }

        return count > 0 ? true : false;
    }

    public String selectNameById(int id) {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        String name = null;

        try {
            pstmt = conn.prepareStatement("select name from my_name where id=?");
            pstmt.setInt(1, id);
            rs = pstmt.executeQuery();

            while (rs.next()) { // rs 다음에서 뽑아낼 데이터가 있느냐 (있으면 트루하고 다음 데이터로 이동, 없으면 펄스
                name = rs.getString("name");

            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            close(rs);
            close(pstmt);

        }

        return name;

    }

    public int selectAccountCountByLoginId(String loginId) {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int count = 0;

        try {
            pstmt = conn.prepareStatement("select count(*) from member where login_id=? and leaved=false ");
            pstmt.setString(1, loginId);
            rs = pstmt.executeQuery();

            while (rs.next()) { // rs 다음에서 뽑아낼 데이터가 있느냐 (있으면 트루하고 다음 데이터로 이동, 없으면 펄스
                count = rs.getInt(1);

            }

        } catch (Exception e) {
            e.printStackTrace();

        } finally {
            close(rs);
            close(pstmt);

        }

        return count;
    }

    public boolean insertMemberInfo(MemberDTO dto) {
        PreparedStatement pstmt = null;
        ResultSet rs = null;
        int count1 = 0;
        int count2 = 0;

        try {
            pstmt = conn.prepareStatement("insert into member_detail(name, mobile_no, birthday, email, zipcode,address,address_detail) " +
                    "values (?,?,?,?,?,?,?)", Statement.RETURN_GENERATED_KEYS);

            pstmt.setString(1, dto.getName());
            pstmt.setString(2, dto.getMobileNo());
            pstmt.setObject(3, dto.getBirthday());
            pstmt.setString(4, dto.getEmail());
            pstmt.setString(5, dto.getZipcode());
            pstmt.setString(6, dto.getAddress());
            pstmt.setString(7, dto.getAddressDetail());
            count1 = pstmt.executeUpdate();
            if (count1 == 0) {
                close(rs);
                close(pstmt);
                return false;
            }

            rs = pstmt.getGeneratedKeys();

            if (rs.next()) {
                dto.setMemberDetail(rs.getInt(1));
            }

            pstmt = conn.prepareStatement("insert into member(login_id, password, member_detail_id)" +
                    "values (?,?,?)");

            pstmt.setString(1, dto.getLoginId());
            pstmt.setString(2, dto.getPassword());
            pstmt.setInt(3, dto.getMemberDetail());
            count2 = pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            close(rs);
            close(conn);
        }

        return count2>0 ? true:false;
    }
}
