package com.member.Service;

import com.Common.AppService;
import com.Common.BCrypt;
import com.Common.ServiceForward;
import com.Common.dto.MemberDTO;
import com.member.Ds.MemberDs;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.time.LocalDate;
import java.util.regex.Pattern;

import static com.Common.BCrypt.gensalt;
import static com.Common.Constants.BASIC_VIEWS_PATH;
import static com.Common.Validator.isValidated;

public class JoinService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 폼 데이터 로드
        // 아이디, 비밀번호, 비밀번호 확인, 이름, 휴대전화 번호, 생년월일, 이메일, 주소
        String loginId = request.getParameter("loginId");
        String password = request.getParameter("password");
        String passwordCheck = request.getParameter("passwordPass");
        String name = request.getParameter("name");
        String mobileNo = request.getParameter("mobileNo");
        String birthday = request.getParameter("birthday");
        String email = request.getParameter("email");
        String address = request.getParameter("address");
        String addressDetail = request.getParameter("addressDetail");



        // 데이터 확인
        if(!isValidated(loginId, "^[a-z0-9]{4,15}$", true)
                ||!isValidated(password, "^[a-zA-Z0-9!@#$]{4,15}$", true)
                ||!isValidated(passwordCheck, "^[a-zA-Z0-9!@#$]{4,15}$", true)
                ||!isValidated(name, "^[가-힣]{2,10}$", true)
                ||!isValidated(mobileNo, "^[0-9]{10,12}$$", true)
                ||!isValidated(birthday, "^[0-9]{8,8}$", false)
                ||!isValidated(email, "^.{1,50}$", true)
                ||!isValidated(address, "^.{1,100}$", false)
                ||!isValidated(addressDetail, "^.{1,100}$", false)){
            return null;
        }

        // 비밀번호 암호화
        password = BCrypt.hashpw(password ,BCrypt.gensalt(12));

        MemberDTO memberDTO = MemberDTO.builder()
                .loginId(loginId)
                .password(password)
                .name(name)
                .mobileNo(mobileNo)
                .email(email)
                .zipcode(address)
                .addressDetail(addressDetail)
                .build();

        // 생일은 선택사항이므로 데이터 존재시만 날짜로 변환
        if(birthday != null && !birthday.equals("")){
            birthday = birthday.substring(0,4)
                    + "-" + birthday.substring(4,6)
                    + "-" + birthday.substring(6);
            memberDTO.setBirthday(LocalDate.parse(birthday));
        }

        //데이터 베이스에 저장
        MemberDs ds = new MemberDs();
        boolean isSuccess = ds.insertMemberInfo(memberDTO);
        if (isSuccess){
            return null;
        } else {

        }

        // 뷰 이동 데이터 세팅 및 리턴
        return  ServiceForward.builder()
                .path(BASIC_VIEWS_PATH + "member/joinresult.jsp")
                .build();
    }
}
