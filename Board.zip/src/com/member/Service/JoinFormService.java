package com.member.Service;

import com.Common.AppService;
import com.Common.ServiceForward;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.Common.Constants.BASIC_VIEWS_PATH;

public class JoinFormService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
       // todo 로그인 여부 확인 

        return  ServiceForward.builder()
                .path(BASIC_VIEWS_PATH + "member/joinform.jsp")
                .build();
    }
}
