package com.Common;

// 뷰에서 리다이렉트 할지 포워드 할지 결정

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class ServiceForward {
    private String path;

    private boolean redirect;
}
