package com.Common;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import static com.Common.Constants.BASIC_VIEWS_PATH;

public class EmptyService implements AppService {
    @Override
    public ServiceForward execute(HttpServletRequest request, HttpServletResponse response) throws Exception {
        return  ServiceForward.builder()
                .path(BASIC_VIEWS_PATH + "main.jsp")
                .build();
    }
}
