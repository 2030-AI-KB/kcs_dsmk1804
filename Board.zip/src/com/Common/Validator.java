package com.Common;

import java.util.regex.Pattern;

public class Validator {
    // 선택값일 때 데이터 검사


    public static boolean isValidated(String data, String regexp, boolean isEssential) {

        boolean isValidated = true;

        // 필수값 일 때 데이터검사
        if (isEssential) { // 필수값일 경우
            if (data == null || data.equals("") || !Pattern.matches(regexp, data)) {
                // 오류 메시지
                isValidated = false;
            }
        } else { // 선택값일 경우
            if (data != null && !data.equals("") && !Pattern.matches(regexp, data)) {
                isValidated = false;

            }

        }
        return isValidated;

    }

    public static boolean isStringEmpty(String str){
        return str == null || str.isEmpty();

    }
}





/*        // 필수값 통과
        if(data == null || .equals('')|| !Pattern.matches(regexp"^[-"))




        return isValieated;
    }
}*/
