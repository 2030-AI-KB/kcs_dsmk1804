package com.Common;

public class Constants {
    public final static String BASIC_VIEWS_PATH  = "/WEB-INF/views/";
}
